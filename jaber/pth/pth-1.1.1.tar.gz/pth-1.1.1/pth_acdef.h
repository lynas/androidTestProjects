/* pth_acdef.h.  Generated automatically by configure.  */
/* pth_acdef.h.in.  Generated automatically from configure.in by autoheader.  */
/*
**  pth_acdef.h -- Autoconf defines
**
**  Copyright (c) 1999 Ralf S. Engelschall <rse@engelschall.com>
**
**  This file is part of GNU Pth, a non-preemptive thread scheduling
**  library which can be found at http://www.gnu.org/software/pth/.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Library General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This library is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
**  Library General Public License for more details.
**
**  You should have received a copy of the GNU Library General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
**  USA, or contact Ralf S. Engelschall <rse@engelschall.com>.
*/

#ifndef _PTH_ACDEF_H_
#define _PTH_ACDEF_H_


/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* the custom Autoconf defines */
#define HAVE_SIG_ATOMIC_T 1
#define HAVE_PID_T 1
/* #undef HAVE_STACK_T */
#define HAVE_SIZE_T 1
#define HAVE_SSIZE_T 1
#define HAVE_OFF_T 1
/* #undef HAVE_GETTIMEOFDAY_ARGS1 */
#define HAVE_SYS_READ 1
#define HAVE_POLLIN 1
#define PTH_DEBUG 1
#define PTH_NSIG 32
#define PTH_MCTX_MTH_use PTH_MCTX_MTH_sjlj
#define PTH_MCTX_DSP_use PTH_MCTX_DSP_ssjlj
#define PTH_MCTX_STK_use PTH_MCTX_STK_sas
#define PTH_STACKGROWTH -1

/* Define if you have the _longjmp function.  */
#define HAVE__LONGJMP 1

/* Define if you have the _setjmp function.  */
#define HAVE__SETJMP 1

/* Define if you have the getcontext function.  */
/* #undef HAVE_GETCONTEXT */

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the longjmp function.  */
#define HAVE_LONGJMP 1

/* Define if you have the makecontext function.  */
/* #undef HAVE_MAKECONTEXT */

/* Define if you have the poll function.  */
#define HAVE_POLL 1

/* Define if you have the readv function.  */
#define HAVE_READV 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the setcontext function.  */
/* #undef HAVE_SETCONTEXT */

/* Define if you have the setjmp function.  */
#define HAVE_SETJMP 1

/* Define if you have the sigaction function.  */
#define HAVE_SIGACTION 1

/* Define if you have the sigaltstack function.  */
#define HAVE_SIGALTSTACK 1

/* Define if you have the siglongjmp function.  */
#define HAVE_SIGLONGJMP 1

/* Define if you have the sigpending function.  */
#define HAVE_SIGPENDING 1

/* Define if you have the sigprocmask function.  */
#define HAVE_SIGPROCMASK 1

/* Define if you have the sigsetjmp function.  */
#define HAVE_SIGSETJMP 1

/* Define if you have the sigstack function.  */
/* #undef HAVE_SIGSTACK */

/* Define if you have the sigsuspend function.  */
#define HAVE_SIGSUSPEND 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the swapcontext function.  */
/* #undef HAVE_SWAPCONTEXT */

/* Define if you have the syscall function.  */
#define HAVE_SYSCALL 1

/* Define if you have the usleep function.  */
#define HAVE_USLEEP 1

/* Define if you have the writev function.  */
#define HAVE_WRITEV 1

/* Define if you have the <errno.h> header file.  */
#define HAVE_ERRNO_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <pthread.h> header file.  */
#define HAVE_PTHREAD_H 1

/* Define if you have the <setjmp.h> header file.  */
#define HAVE_SETJMP_H 1

/* Define if you have the <sfio.h> header file.  */
/* #undef HAVE_SFIO_H */

/* Define if you have the <signal.h> header file.  */
#define HAVE_SIGNAL_H 1

/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1

/* Define if you have the <stdio.h> header file.  */
#define HAVE_STDIO_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/resource.h> header file.  */
#define HAVE_SYS_RESOURCE_H 1

/* Define if you have the <sys/socket.h> header file.  */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/uio.h> header file.  */
#define HAVE_SYS_UIO_H 1

/* Define if you have the <sys/wait.h> header file.  */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the nsl library (-lnsl).  */
/* #undef HAVE_LIBNSL */

/* Define if you have the sfio library (-lsfio).  */
/* #undef HAVE_LIBSFIO */

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

#endif /* _PTH_ACDEF_H_ */

