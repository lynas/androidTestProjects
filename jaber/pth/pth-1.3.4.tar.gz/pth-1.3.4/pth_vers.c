/*
**  pth_vers.c -- Version Information
**  [automatically generated and maintained by GNU shtool]
*/

#ifdef _AS_HEADER

#ifndef _PTH_VERS_C
#define _PTH_VERS_C
#define PTH_VERSION 0x103204
extern const int  PTH_Version;
extern const char PTH_VersionStr[];
extern const char PTH_Hello[];
extern const char PTH_GNUVersion[];
extern const char PTH_WhatID[];
extern const char PTH_RCSIdentID[];
extern const char PTH_WebID[];
extern const char PTH_PlainID[];
#endif /* _PTH_VERS_C */

#else

const int  PTH_Version      = 0x103204;
const char PTH_VersionStr[] = "1.3.4 (16-Apr-2000)";
const char PTH_Hello[]      = "This is GNU Pth, Version 1.3.4 (16-Apr-2000)";
const char PTH_GNUVersion[] = "GNU Pth Version 1.3.4";
const char PTH_WhatID[]     = "@(#)GNU Pth Version 1.3.4 (16-Apr-2000)";
const char PTH_RCSIdentID[] = "$Id: GNU Pth 1.3.4 16-Apr-2000 $";
const char PTH_WebID[]      = "GNU Pth/1.3.4";
const char PTH_PlainID[]    = "1.3.4";

#endif
