/*
**  acconfig.h -- Autoconf result header
**
**  Copyright (c) 1999 Ralf S. Engelschall <rse@engelschall.com>
**
**  This file is part of GNU Pth, a non-preemptive thread scheduling
**  library which can be found at http://www.gnu.org/software/pth/.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Library General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This library is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
**  Library General Public License for more details.
**
**  You should have received a copy of the GNU Library General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
**  USA, or contact Ralf S. Engelschall <rse@engelschall.com>.
*/

#ifndef _PTH_CONF_H
#define _PTH_CONF_H

/* a little wrapper for sigsetjmp() to help the Autoconf stuff */
#define sigsetjmp1(jp) sigsetjmp(jp, 1)

@TOP@

/* the custom Autoconf defines */
#undef HAVE_SIG_ATOMIC_T
#undef HAVE_PID_T
#undef HAVE_STACK_T
#undef HAVE_SIZE_T
#undef HAVE_SSIZE_T
#undef HAVE_GETTIMEOFDAY_ARGS1
#undef HAVE_SYS_READ
#undef HAVE_POLLIN
#undef PTH_DEBUG
#undef PTH_MCTXSET_SIGSTACK
#undef PTH_MCTXSET_LINUX
#undef PTH_STACKSGROWDOWN
#undef PTH_EMULATE_SIGSETJMP
#undef pth_sigsetjmp
#undef pth_siglongjmp
#undef pth_sigjmp_buf
#undef PTH_NSIG

@BOTTOM@

#endif /* _PTH_CONF_H */

