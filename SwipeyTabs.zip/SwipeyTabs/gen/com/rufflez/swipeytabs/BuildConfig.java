/** Automatically generated file. DO NOT MODIFY */
package com.rufflez.swipeytabs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}